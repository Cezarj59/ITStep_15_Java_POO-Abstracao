package main;

import menu.Menus;

public class Main {

    public static void main(String[] args) {
        Menus.menu();
    }
}
